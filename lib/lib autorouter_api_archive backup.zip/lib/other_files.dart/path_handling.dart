import 'dart:developer';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;

Future<String> cacheFilePath(String name, String extension) async {
  final Directory directory = await getApplicationDocumentsDirectory();
  final Directory cacheDirectory = await getApplicationCacheDirectory();
  log('directory: $directory');

  final utcNow = DateTime.now().toUtc();

  final String dir = path.dirname(cacheDirectory.path);

  final fileName = path.join(dir, name);
  return path.setExtension(fileName, extension);
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

//import 'autorouter/initialize_autorouter.dart';
import 'autorouter/token/token_buttons.dart';
//import 'parse_result.dart';


void main() {
  runApp(
    // Adding ProviderScope enables Riverpod for the entire project
    const ProviderScope(child: MyApp()),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(colorScheme: .fromSeed(seedColor: Colors.deepPurple)),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,

        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: .center,
          children: [/* 
            ElevatedButton(
              child: Text('parseD'),
              onPressed: () {
                

                final String dText = 'sfsdfc';
                final List<String> dList = dText.split('');
                for (var dField in dList) {
                  final ParseResult parseResult = dParse(dField);
                  debugPrint(parseResult.toString());
                }
                debugPrint('test1');
              },
            ), */
            
            /* 
            ElevatedButton(child: Text('connectAutorouter'), onPressed: ()  {
              initializeAppAndGetPib();
            }), */
            GetPIBAllPageButton(),
           /*  ElevatedButton(child: Text('initializeAppAndGetPibAllPage'), onPressed: ()  {
              initializeAppAndGetPibAllPage();
            }), */
            
         /*    ElevatedButton(child: Text('initializeAppAndGetPibAllPageV2'), onPressed: ()  {
             // initializeAppAndGetPibAllPageV2();
            }), */
           // ElevatedButton(child: Text('get notams'), onPressed: () {}),
           // TokenButton(),
           // AutorouterLoginWidget(),
            TokenCredentialsWidget(),
            const Text('You have pushed the button this many times:'),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}


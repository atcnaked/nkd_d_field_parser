import 'dart:convert';
import 'package:http/http.dart' as http;
import 'get_pib.dart';

void getPibAllPage(String token ) async {

    final List<String> icaosCode3Fir = ['LFBB','LFFF','LFMM'];
    final List<String> icaosCodeBB = ['LFBB',];
    final List<String> icaosCode = icaosCodeBB;
    final int? limit = null; 
    final int? retryNb = null; 
    final DateTime? startValidity= null;
    final DateTime? endValidity= null;
print('selected icaosCode: $icaosCode');
    await fetchPibNotamsMultiPage(
      accessToken: token,
     // icaoCodes: ['LFBB','LFFF','LFMM'],
      icaoCodes: icaosCode,
     // offset: 0,
      limit: limit,
      startValidity: startValidity,
      endValidity: endValidity,
      retryNb: retryNb,
    );
}
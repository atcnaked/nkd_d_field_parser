import 'package:flutter/foundation.dart';

// ignore_for_file: public_member_api_docs, sort_constructors_first
class AutorouterNotamGem {
  final int? id;
  final int? modified;
  final String? nof;
  final String? series;
  final int? number;
  final int? year;
  final String? type;
  final String? referredSeries;
  final int? referredNumber;
  final int? referredYear;
  final String? fir;
  final String? code23;
  final String? code45;
  final String? traffic;
  final String? purpose;
  final String? scope;
  final int? lower;
  final int? upper;
  final int? lon;
  final int? lat;
  final int? radius;
  final int? neLon;
  final int? neLat;
  final int? swLon;
  final int? swLat;
  final int? startValidity;
  final int? endValidity;
  final String?  estimation; 
  final List<String?> itemA;
  final String? itemD;
  final String? itemE;

  AutorouterNotamGem({
    required this.id,
    required this.modified,
    required this.nof,
    required this.series,
    required this.number,
    required this.year,
    this.type,
    this.referredSeries,
    this.referredNumber,
    this.referredYear,
    this.fir,
    this.code23,
    this.code45,
    this.traffic,
    this.purpose,
    this.scope,
    this.lower,
    this.upper,
    this.lon,
    this.lat,
    this.radius,
    this.neLon,
    this.neLat,
    this.swLon,
    this.swLat,
    required this.startValidity,
    required this.endValidity,
    this.estimation,
    required this.itemA,
    this.itemD,
   required this.itemE,
  });

  factory AutorouterNotamGem.fromJson(Map<String, dynamic> json) {
    return AutorouterNotamGem(
      id: json['id'] ,
      modified: json['modified'] ,
      nof: json['nof'],
      series: json['series'],
      number: json['number'],
      year: json['year'],
      type: json['type'],
      referredSeries: json['referredseries'],
      referredNumber: json['referrednumber'],
      referredYear: json['referredyear'],
      fir: json['fir'],
      code23: json['code23'],
      code45: json['code45'],
      traffic: json['traffic'],
      purpose: json['purpose'],
      scope: json['scope'],
      lower: json['lower'],
      upper: json['upper'],
      lon: json['lon'],
      lat: json['lat'],
      radius: json['radius'],
      neLon: json['nelon'],
      neLat: json['nelat'],
      swLon: json['swlon'],
      swLat: json['swlat'],
      startValidity: json['startvalidity'] ?? 0,
      endValidity: json['endvalidity'] ?? 0,
      estimation: json['estimation'],
      // Safely parse the list of strings
      itemA: List<String>.from(json['itema'] ?? []),
      itemD: json['itemd'],
      itemE: json['iteme'],
    );
  }

  // --- Helpful Getters for your Flutter UI ---

  /// Returns the official ICAO NOTAM ID (e.g., "F0627/25")
  String get formattedId {
    if (series != null && number != null && year != null) {
      // Pads the number to 4 digits (e.g., 627 becomes 0627)
      return '$series${number.toString().padLeft(4, '0')}/$year';
    }
    return id.toString(); // Fallback to the DB id
  }

  /// Converts Unix timestamp to standard Dart DateTime (UTC)
  DateTime get validFrom =>
      DateTime.fromMillisecondsSinceEpoch(startValidity! * 1000, isUtc: true);

  /// Handles the PERM magic number gracefully for your UI
  String get displayEndDate {
    if (endValidity == 2147483647) {
      return 'PERM';
    }
    return DateTime.fromMillisecondsSinceEpoch(
      endValidity! * 1000,
      isUtc: true,
    ).toString();
  }

  /// Converts Garmin Semicircle lat to standard Decimal Degrees
  double? get centerLat {
    if (lat == null) return null;
    return lat! * 90.0 / (1 << 30);
  }

  /// Converts Garmin Semicircle lon to standard Decimal Degrees
  double? get centerLon {
    if (lon == null) return null;
    return lon! * 90.0 / (1 << 30);
  }

  @override
  String toString() {
    return 'AutorouterNotamGem(id: $id, modified: $modified, nof: $nof, series: $series, number: $number, year: $year, type: $type, referredSeries: $referredSeries, referredNumber: $referredNumber, referredYear: $referredYear, fir: $fir, code23: $code23, code45: $code45, traffic: $traffic, purpose: $purpose, scope: $scope, lower: $lower, upper: $upper, lon: $lon, lat: $lat, radius: $radius, neLon: $neLon, neLat: $neLat, swLon: $swLon, swLat: $swLat, startValidity: $startValidity, endValidity: $endValidity, estimation: $estimation, itemA: $itemA, itemD: $itemD, itemE: $itemE)';
  }

  @override
  bool operator ==(covariant AutorouterNotamGem other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.modified == modified &&
        other.nof == nof &&
        other.series == series &&
        other.number == number &&
        other.year == year &&
        other.type == type &&
        other.referredSeries == referredSeries &&
        other.referredNumber == referredNumber &&
        other.referredYear == referredYear &&
        other.fir == fir &&
        other.code23 == code23 &&
        other.code45 == code45 &&
        other.traffic == traffic &&
        other.purpose == purpose &&
        other.scope == scope &&
        other.lower == lower &&
        other.upper == upper &&
        other.lon == lon &&
        other.lat == lat &&
        other.radius == radius &&
        other.neLon == neLon &&
        other.neLat == neLat &&
        other.swLon == swLon &&
        other.swLat == swLat &&
        other.startValidity == startValidity &&
        other.endValidity == endValidity &&
        other.estimation == estimation &&
        listEquals(other.itemA, itemA) &&
        other.itemD == itemD &&
        other.itemE == itemE;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        modified.hashCode ^
        nof.hashCode ^
        series.hashCode ^
        number.hashCode ^
        year.hashCode ^
        type.hashCode ^
        referredSeries.hashCode ^
        referredNumber.hashCode ^
        referredYear.hashCode ^
        fir.hashCode ^
        code23.hashCode ^
        code45.hashCode ^
        traffic.hashCode ^
        purpose.hashCode ^
        scope.hashCode ^
        lower.hashCode ^
        upper.hashCode ^
        lon.hashCode ^
        lat.hashCode ^
        radius.hashCode ^
        neLon.hashCode ^
        neLat.hashCode ^
        swLon.hashCode ^
        swLat.hashCode ^
        startValidity.hashCode ^
        endValidity.hashCode ^
        estimation.hashCode ^
        itemA.hashCode ^
        itemD.hashCode ^
        itemE.hashCode;
  }
}

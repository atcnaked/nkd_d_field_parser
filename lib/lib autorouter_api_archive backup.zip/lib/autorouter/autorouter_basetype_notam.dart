import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first
/// a AutorouterNotam where field have the expected type. No check is made on the meaning of the fields.
///
/// The fromMap constructor has been modified and accepts only expected types (else crash)
/// String estimation = 'EST' or null
/// String type = 'N' or 'R' or other maybe
/// bool suppressed
/// nullable values:  {referredseries, referrednumber, referredyear, estimation, itemd, itemf, itemg}
class AutorouterBaseTypeNotam {




  final bool suppressed;
  final int id;
  final int modified;
  final String nof;
  final String series;
  final int number;
  final int year; ////
  final String type; ////
  final String? referredSeries;
  final int? referredNumber; ////
  final int? referredYear; /////
  final String fir;
  final String code23;
  final String code45;
  final String traffic;
  final String purpose;
  final String scope;
  final int lower;
  final int upper;
  final int lon;
  final int lat;
  final int radius;
  final int neLon;
  final int neLat;
  final int swLon;
  final int swLat;
  final int startValidity;
  final int endValidity;

  final String? estimation;
  final List<String> itemA;
  final String? itemD;
  final String itemE;
  final String? itemF;
  final String? itemG;
  
  /// the NotamId as P0264/26. Does not mention the nof
  String get notamId {
final numberFormatted = number.toString().padLeft(4, '0');
    return  ('$series$numberFormatted/$year');
}
  AutorouterBaseTypeNotam({
    required this.suppressed,
    required this.id,
    required this.modified,
    required this.nof,
    required this.series,
    required this.number,
    required this.year,
    required this.type,
    required this.referredSeries,
    required this.referredNumber,
    required this.referredYear,
    required this.fir,
    required this.code23,
    required this.code45,
    required this.traffic,
    required this.purpose,
    required this.scope,
    required this.lower,
    required this.upper,
    required this.lon,
    required this.lat,
    required this.radius,
    required this.neLon,
    required this.neLat,
    required this.swLon,
    required this.swLat,
    required this.startValidity,
    required this.endValidity,
    required this.estimation,
    required this.itemA,
    required this.itemD,
    required this.itemE,
    required this.itemF,
    required this.itemG,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'suppressed': suppressed,
      'id': id,
      'modified': modified,
      'nof': nof,
      'series': series,
      'number': number,
      'year': year,
      'type': type,
      'referredSeries': referredSeries,
      'referredNumber': referredNumber,
      'referredYear': referredYear,
      'fir': fir,
      'code23': code23,
      'code45': code45,
      'traffic': traffic,
      'purpose': purpose,
      'scope': scope,
      'lower': lower,
      'upper': upper,
      'lon': lon,
      'lat': lat,
      'radius': radius,
      'neLon': neLon,
      'neLat': neLat,
      'swLon': swLon,
      'swLat': swLat,
      'startValidity': startValidity,
      'endValidity': endValidity,
      'estimation': estimation,
      'itemA': itemA,
      'itemD': itemD,
      'itemE': itemE,
      'itemF': itemF,
      'itemG': itemG,
    };
  }

  factory AutorouterBaseTypeNotam.fromMap(Map<String, dynamic> map) {
    return AutorouterBaseTypeNotam(
      suppressed: map['suppressed'] as bool,
      id: map['id'] as int,
      modified: map['modified'] as int,
      nof: map['nof'] as String,
      series: map['series'] as String,
      number: map['number'] as int,
      year: map['year'] as int,
      type: map['type'] as String,
      referredSeries: map['referredseries'] as String?,
      referredNumber: map['referrednumber'] as int?,
      referredYear: map['referredyear'] as int?,
      fir: map['fir'] as String,
      code23: map['code23'] as String,
      code45: map['code45'] as String,
      traffic: map['traffic'] as String,
      purpose: map['purpose'] as String,
      scope: map['scope'] as String,
      lower: map['lower'] as int,
      upper: map['upper'] as int,
      lon: map['lon'] as int,
      lat: map['lat'] as int,
      radius: map['radius'] as int,
      neLon: map['nelon'] as int,
      neLat: map['nelat'] as int,
      swLon: map['swlon'] as int,
      swLat: map['swlat'] as int,
      startValidity: map['startvalidity'] as int,
      endValidity: map['endvalidity'] as int,
      estimation: map['estimation'] as String?,

      itemD: map['itemd'] as String?,
      itemE: map['iteme'] as String,
      itemF: map['itemf'] as String?,
      itemG: map['itemg'] as String?,
      /// here List Dynamic and not List String, may cause bugs if itema is not List String
      itemA: List<String>.from((map['itema'] )),
    );
  }

  String toJson() => json.encode(toMap());

  factory AutorouterBaseTypeNotam.fromJson(String source) =>
      AutorouterBaseTypeNotam.fromMap(
        json.decode(source) as Map<String, dynamic>,
      );
}



import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;

//import 'autorouter_notam.dart';
import 'autorouter_basetype_notam.dart';
import 'autorouter_notam_by_gemini.dart';
import 'autorouter_notam_validation.dart';
import 'autorouter_notam_with_notam_id.dart';

/// Fetches NOTAMs based on the official Autorouter API specification.
Future<void> fetchPibNotamsMultiPage({
  required String accessToken,
  required List<String> icaoCodes, // e.g., ['LFFF', 'LFBB']
  //required int offset,
  required int? limit,
  required DateTime? startValidity,
  required DateTime? endValidity,
  required int? retryNb,
}) async {
  final int maxTry = retryNb??1;

   int tryCount = 0;
try {
while (tryCount!=maxTry) {
  tryCount++;

  final List<AutorouterBaseTypeNotam>? AutorouterNotamGems =
      await fetchAllPibNotamsRetries(accessToken, icaoCodes, maxTry);

}
  
} catch (e) {
  
}
//  print('found AutorouterNotamGems Count: ${AutorouterNotamGems?.length}');
}

/// Fetches NOTAMs based on the official Autorouter API specification.
Future<void> fetchPibNotamszzzzzz({
  required String accessToken,
  required List<String> icaoCodes, // e.g., ['LFFF', 'LFBB']
  int offset = 0,
  int limit = 10,
  DateTime? startValidity,
  DateTime? endValidity,
}) async {
  // 1. Build the query parameters map
  final Map<String, String> queryParams = {
    // jsonEncode turns the Dart list into the required '["LFFF"]' string format
    'itemas': jsonEncode(icaoCodes),
    'offset': offset.toString(),
    'limit': limit.toString(),
  };

  // 2. Handle the optional Unix epoch time conversions
  if (startValidity != null) {
    // Convert Dart DateTime to seconds since Unix epoch
    queryParams['startvalidity'] =
        (startValidity.millisecondsSinceEpoch ~/ 1000).toString();
  }

  if (endValidity != null) {
    queryParams['endvalidity'] = (endValidity.millisecondsSinceEpoch ~/ 1000)
        .toString();
  }

  // 3. Construct the URI safely.
  // Uri.https automatically URL-encodes the JSON array and all parameters.
  final uri = Uri.https(
    'api.autorouter.aero', // Host
    '/v1.0/notam', // Path
    queryParams, // The encoded query parameters
  );

  print('Executing GET request to: $uri');

  // 4. Make the request
  final response = await http.get(
    uri,
    headers: {
      'Authorization': 'Bearer $accessToken',
      'Accept': 'application/json',
    },
  );

  // 5. Handle the response
  if (response.statusCode == 200) {
    final jsonData = jsonDecode(response.body);

    // Total available rows (for information)
    final int totalItems = jsonData['total'] ?? 0;
    print('Total NOTAMs matching criteria: $totalItems');

    // Parse your rows
    final List rows = jsonData['rows'] ?? [];

    // Create an empty, strongly-typed list
    final List<AutorouterNotamGem> notamList = [];
    int counter = 0;
    // Loop through the raw rows
    for (var row in rows) {
      // Convert the single map into an object
      final AutorouterNotamGem parsedNotam;
      try {
        parsedNotam = AutorouterNotamGem.fromJson(row);
        counter++;
        print('counter: $counter');
      } catch (e) {
        log('could not parse row: $counter, $e\nrow:$row, ');
        break;
      }
      // Add it to your final list
      notamList.add(parsedNotam);
    }

    print('Successfully parsed ${notamList.length} NOTAMs.');

    print('Successfully fetched ${rows.length} NOTAMs in this batch.');
    for (var i = 0; i < rows.length; i++) {
      print('');
      print('//////////////////////////');
      //  print('rows $i: $rows');
    }

    // Here is where you map it to the NotamResponse model we built earlier!
  } else {
    print('Failed to fetch NOTAMs. Status Code: ${response.statusCode}');
    print('Error Body: ${response.body}');
  }
}

Future<List<AutorouterBaseTypeNotam>?> fetchAllPibNotamsRetries(
  String accessToken,
  List<String> icaoCodes,
  int retryLimit,
) async {
  int retries = 0;
  while (retries < retryLimit) {
    try {
      final List<AutorouterBaseTypeNotam> res =
          await fetchAllPibNotamsThrowIfDbChange(accessToken, icaoCodes);
      return res;
    } catch (e) {
      retries++;
      log(
        'error in fetchAllPibNotamsThrowIfDbChange, retrying ($retries/$retryLimit)\nerror $e',
      );
    }
  }
  return null;
}

Future<List<AutorouterBaseTypeNotam>> fetchAllPibNotamsThrowIfDbChange(
  String accessToken,
  List<String> icaoCodes,
) async {
  final int limit = 100;
  int offset = 0;
  int totalItems = -1; // Set to 1 just to ensure we enter the while loop
  int itemNumberFirstResponse=-7;
  //int? expectedItemsCount;

  // The Map is our secret weapon for deduplication.
  // Key = NOTAM ID, Value = The NOTAM Object.
  Map<int, AutorouterNotamGem> uniqueNotams = {};
  Map<int, AutorouterBaseTypeNotam> uniqueNotamsAutorouterBaseTypeNotam = {};
  final Set<String> nullValues = {};

  // Keep looping as long as our offset is less than the total available NOTAMs

  bool hasMoreData = true; // Our new, safe loop controller
  //////////////////////////////////
  //////////////////////////////////
  //////////////////////////////////
  //////////////////////////////////
  //////////////////////////////////
  while (hasMoreData) {
    /////
    final queryParams = {
      'itemas': jsonEncode(icaoCodes),
      'offset': offset.toString(),
      'limit': limit.toString(),
    };

    final uri = Uri.https('api.autorouter.aero', '/v1.0/notam', queryParams);

    print('Fetching NOTAMs from offset $offset...');

    final response = await http.get(
      uri,
      headers: {
        'Authorization': 'Bearer $accessToken',
        'Accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);

      // getting total Items for information
      totalItems = jsonData['total'] ?? 0;
      if (itemNumberFirstResponse==-7&& totalItems != null) {
        // the first loop is detected by the value of itemNumberFirstResponse being -7; 
        // initialized with totalItems
        itemNumberFirstResponse = totalItems;
      }
      itemNumberFirstResponse++;
      // Only grab the total on the first request so we can print it
      if (offset == 0) {
        final int expectedItemsCount = jsonData['total'] ?? -1;
        print('expectedItemsCount: $expectedItemsCount');
      }
      

      final List rows = jsonData['rows'] ?? [];

      print('adding: ${rows.length} elements to uniqueNotams');
      // Parse the rows and drop them into the Map
      int counter = 0;
      for (var row in rows) {
        counter++;
      //  final notam = AutorouterNotamGem.fromJson(row);
        final (AutorouterBaseTypeNotam?, String?) res =            getValidFromAutorouterBaseTypeNotam(row);
        final AutorouterBaseTypeNotam autorouterBaseTypeNotam;
        if (res.$1 != null) {
         // print('row before parse: $row before parse');
          autorouterBaseTypeNotam = res.$1!;
        print('parsing notam: $counter ${autorouterBaseTypeNotam.notamId}');
        } else {
          print('validOrError.2: ${res.$2}');
          throw Exception('error when parsing AutorouterBaseTypeNotam \n${res.$2}');
        }

     /*    final AutorouterNotamIdBC? autorouterNotamIdBC =
            getAutorouterNotamIdBCFromAutorouterNotamGem(
              autorouterNotam: notam,
            ); */
        //print('autorouterNotamIdBC: $autorouterNotamIdBC');
        //   row is  Map<String, dynamic> so keys are String
        //
     /*    if (counter < 4) {
          print('work counter == 1');

          if (autorouterNotamIdBC != null) {
            print('autorouterNotamIdBC: $autorouterNotamIdBC');
          }
        } */

        // If the ID already exists, this just overwrites it safely. No duplicates!
            uniqueNotamsAutorouterBaseTypeNotam[autorouterBaseTypeNotam.id] = autorouterBaseTypeNotam;    // uniqueNotams[notam.id] = notam;

     /*    if (uniqueNotamsAutorouterBaseTypeNotam.keys.contains(autorouterBaseTypeNotam.id)) {
          print('uniqueNotamsAutorouterBaseTypeNotam.keys.contains({$autorouterBaseTypeNotam.id}');

          final bool comp = uniqueNotamsAutorouterBaseTypeNotam[autorouterBaseTypeNotam.id] == autorouterBaseTypeNotam;

          if (comp == false) {
            print('but no !! they are not equal !');
          }
        } */
        // If the ID already exists, this just overwrites it safely. No duplicates!
    /*     if (uniqueNotams.keys.contains(notam.id)) {
          print('uniqueNotams.keys.contains({$notam.id})\n${notam}');

          final bool comp = uniqueNotams[notam.id] == notam;

          if (comp == false) {
            print('but no !! they are not equal !');
          }
        } */
        // uniqueNotams[notam.id] = notam;
      }

      // THE BULLETPROOF CHECK: if no more then stop
      if (rows.length == 0) {
        hasMoreData = false; // This will gracefully end the while loop
      } else {
        // Increment the offset to grab the next batch on the next loop iteration
        offset += limit; // Otherwise, advance the offset and pull the next 100
      }
    } else {
      // If we hit an error (like a 401 or 500), break the loop so we don't get stuck forever
      throw Exception('Failed to fetch. Status Code: ${response.statusCode}');
    }
    //////////////////////////////////
    //////////////////////////////////
    //////////////////////////////////
    //////////////////////////////////
    //////////////////////////////////
  }

  print(
    'Finished! Downloaded ${uniqueNotamsAutorouterBaseTypeNotam.length} unique NOTAMs out of $itemNumberFirstResponse reported on the server.',
  );
 // print('nullValues: $nullValues');
  // Convert the Map values back into a standard Dart List for your Flutter UI
  return uniqueNotamsAutorouterBaseTypeNotam.values.toList();
}

/// Fetches NOTAMs based on the official Autorouter API specification.
Future<void> fetchNotams1Batch({
  required String accessToken,
  required List<String> icaoCodes, // e.g., ['LFFF', 'LFBB']
  int offset = 0,
  int limit = 10,
  DateTime? startValidity,
  DateTime? endValidity,
}) async {
  // 1. Build the query parameters map
  final Map<String, String> queryParams = {
    // jsonEncode turns the Dart list into the required '["LFFF"]' string format
    'itemas': jsonEncode(icaoCodes),
    'offset': offset.toString(),
    'limit': limit.toString(),
  };

  // 2. Handle the optional Unix epoch time conversions
  if (startValidity != null) {
    // Convert Dart DateTime to seconds since Unix epoch
    queryParams['startvalidity'] =
        (startValidity.millisecondsSinceEpoch ~/ 1000).toString();
  }

  if (endValidity != null) {
    queryParams['endvalidity'] = (endValidity.millisecondsSinceEpoch ~/ 1000)
        .toString();
  }

  // 3. Construct the URI safely.
  // Uri.https automatically URL-encodes the JSON array and all parameters.
  final uri = Uri.https(
    'api.autorouter.aero', // Host
    '/v1.0/notam', // Path
    queryParams, // The encoded query parameters
  );

  print('Executing GET request to: $uri');

  // 4. Make the request
  final response = await http.get(
    uri,
    headers: {
      'Authorization': 'Bearer $accessToken',
      'Accept': 'application/json',
    },
  );

  // 5. Handle the response
  if (response.statusCode == 200) {
    final jsonData = jsonDecode(response.body);

    // Total available rows (for information)
    final int totalItems = jsonData['total'] ?? 0;
    print('Total NOTAMs matching criteria: $totalItems');

    // Parse your rows
    final List rows = jsonData['rows'] ?? [];

    // Create an empty, strongly-typed list
    final List<AutorouterNotamGem> notamList = [];
    int counter = 0;
    // Loop through the raw rows
    for (var row in rows) {
      // Convert the single map into an object
      final AutorouterNotamGem parsedNotam;
      try {
        parsedNotam = AutorouterNotamGem.fromJson(row);
        counter++;
        print('counter: $counter');
      } catch (e) {
        log('could not parse row: $counter, $e\nrow:$row, ');
        break;
      }
      // Add it to your final list
      notamList.add(parsedNotam);
    }

    print('Successfully parsed ${notamList.length} NOTAMs.');

    print('Successfully fetched ${rows.length} NOTAMs in this batch.');
    for (var i = 0; i < rows.length; i++) {
      print('');
      print('//////////////////////////');
      //  print('rows $i: $rows');
    }

    // Here is where you map it to the NotamResponse model we built earlier!
  } else {
    print('Failed to fetch NOTAMs. Status Code: ${response.statusCode}');
    print('Error Body: ${response.body}');
  }
}

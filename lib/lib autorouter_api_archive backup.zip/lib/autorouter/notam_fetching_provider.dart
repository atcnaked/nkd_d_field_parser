import 'package:autorouter_api_and_d_parse/autorouter/token/token_provider_secure_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'token/token_response.dart';

final notamLoadingNotifierProvider =
    NotifierProvider<NotamLoadingNotifier, NotamLoadingState>(
      NotamLoadingNotifier.new,
    );

class NotamLoadingNotifier extends Notifier<NotamLoadingState> {
  @override
  build() {
    return NotamLoadingInitial();
  }

  void ack() {
    state = NotamLoadingInitial();
  }

  void fetch() async {
    final TokenResponse? tkr = ref.read(tokenResponseNotifierProvider);
    if (tkr == null) {
      state = NotamLoadingFailure(
        'Notam loading impossible, no token available',
      );
      return;
    }

    state = NotamLoadingInProgress(current: 0, total: -1, tryNb:1);

   // for (var element in collection) {}
  }
}

sealed class NotamLoadingState {}

class NotamLoadingInitial extends NotamLoadingState {}

class NotamLoadingInProgress extends NotamLoadingState {
  final int tryNb;
  final int current;
  final int total;
  final String message;

  NotamLoadingInProgress({
    required this.current,
    required this.total,
    this.message = '',
    required this.tryNb,
  });
}

class NotamLoadingSuccess extends NotamLoadingState {
  final List<dynamic> notams;
  NotamLoadingSuccess(this.notams);
}

class NotamLoadingFailure extends NotamLoadingState {
  final String error;
  NotamLoadingFailure(this.error);
}

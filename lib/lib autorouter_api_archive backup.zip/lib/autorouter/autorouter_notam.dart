import 'autorouter_notam_by_gemini.dart';
import 'autorouter_notam_with_notam_id.dart';


const mandatoryKeys2 = [
  'id',
  'nof',
  'series',
  'number',
  'year',
  'type',
  'modified',
  'suppressed',
  'referredseries',
  'referrednumber',
  'referredyear',
  'startvalidity',
  'endvalidity',
  'estimation',
  'fir',
  'code23',
  'code45',
  'traffic',
  'purpose',
  'scope',
  'lower',
  'upper',
  'lon',
  'lat',
  'radius',
  'itema',
  'itemd',
  'iteme',
  'itemf',
  'itemg',
  'nelon',
  'nelat',
  'swlon',
  'swlat',
];
/* 
(AutorouterNotam?, String?) getValidatedAutorouterNotam(
  AutorouterNotamGem autorouterNotamGem,
  dynamic row,
) {
  final Map<String, dynamic> json = row as Map<String, dynamic>;
  final List<String> missingKeys = [];
  for (var k in mandatoryKeys) {
    if (!json.keys.contains(k)) {
      print('key $k missing in notam json: $json');
    } else {
      print('key $k present');
    }
  }
  if (missingKeys.isEmpty) {
    final arnot = AutorouterNotam.fromJson(json);

    return (arnot, null);
  } else {
    return (null, 'key $k missing in notam json: $json');
  }
}
 */
// ignore_for_file: public_member_api_docs, sort_constructors_first
/// null values:  {referredseries, referrednumber, referredyear, estimation, itemd, itemf, itemg}
/// String estimation = 'EST' or null
/// bool suppressed

class AutorouterNotam {
  final int id;
  final int modified;
  final String nof;
  final String series;
  final String number;
  final String year;
  final String type;
  final String? referredSeries;
  final String? referredNumber;
  final String? referredYear;
  final String fir;
  final String code23;
  final String code45;
  final String traffic;
  final String purpose;
  final String scope;
  final int lower;
  final int upper;
  final int lon;
  final int lat;
  final int radius;
  final int neLon;
  final int neLat;
  final int swLon;
  final int swLat;
  final int startValidity;
  final int endValidity;
  final String? estimation;
  final List<String> itemA;
  final String? itemD;
  final String itemE;
  AutorouterNotam({
    required this.id,
    required this.modified,
    required this.nof,
    required this.series,
    required this.number,
    required this.year,
    required this.type,
    required this.referredSeries,
    required this.referredNumber,
    required this.referredYear,
    required this.fir,
    required this.code23,
    required this.code45,
    required this.traffic,
    required this.purpose,
    required this.scope,
    required this.lower,
    required this.upper,
    required this.lon,
    required this.lat,
    required this.radius,
    required this.neLon,
    required this.neLat,
    required this.swLon,
    required this.swLat,
    required this.startValidity,
    required this.endValidity,
    required this.estimation,
    required this.itemA,
    required this.itemD,
    required this.itemE,
  });

  factory AutorouterNotam.fromJson(Map<String, dynamic> json) {
    return AutorouterNotam(
      id: int.parse(json['id']),
      modified: int.parse(json['modified']),
      nof: json['nof'],
      series: json['series'],
      number: json['number'],
      year: json['year'],
      type: json['type'],
      referredSeries: json['referredseries'] ,
      referredNumber: json['referrednumber'],
      referredYear: json['referredyear'],
      fir: json['fir'],
      code23: json['code23'],
      code45: json['code45'],
      traffic: json['traffic'],
      purpose: json['purpose'],
      scope: json['scope'],
      lower: json['lower'],
      upper: json['upper'],
      lon: json['lon'],
      lat: json['lat'],
      radius: json['radius'],
      neLon: json['nelon'],
      neLat: json['nelat'],
      swLon: json['swlon'],
      swLat: json['swlat'],
      startValidity: json['startvalidity'],
      endValidity: json['endvalidity'],
      estimation: json['estimation'] ,
      // Safely parse the list of strings
      itemA: List<String>.from(json['itema']),
      itemD: json['itemd'] ,
      itemE: json['iteme'],
    );
  }

  // --- Helpful Getters for your Flutter UI ---

  /// Returns the official ICAO NOTAM ID (e.g., "F0627/25")
  String get formattedId {
    return '$series${number.toString().padLeft(4, '0')}/$year';
  }

  /// Converts Unix timestamp to standard Dart DateTime (UTC)
  DateTime get validFrom =>
      DateTime.fromMillisecondsSinceEpoch(startValidity * 1000, isUtc: true);

  /// Handles the PERM magic number gracefully for your UI
  String get displayEndDate {
    if (endValidity == 2147483647) {
      return 'PERM';
    }
    return DateTime.fromMillisecondsSinceEpoch(
      endValidity * 1000,
      isUtc: true,
    ).toString();
  }

  /// Converts Garmin Semicircle lat to standard Decimal Degrees
  double get centerLatDD {
    return lat * 90.0 / (1 << 30);
  }

  /// Converts Garmin Semicircle lon to standard Decimal Degrees
  double get centerLonDD {
    return lon * 90.0 / (1 << 30);
  }
}

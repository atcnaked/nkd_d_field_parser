// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:developer';

import 'autorouter_notam_by_gemini.dart' show AutorouterNotamGem;

/// an AutorouterNotam where field NotamId, B, C has been decoded
class AutorouterNotamIdBC {
  final AutorouterNotamGem autorouterNotam;
  final AutorouterNotamId notamId;
  AutorouterNotamIdBC({required this.autorouterNotam, required this.notamId});


  @override
  String toString() => 'NotamIdBC: $notamId)';
}

  AutorouterNotamIdBC? getAutorouterNotamIdBCFromAutorouterNotamGem({
    required AutorouterNotamGem autorouterNotam,
  }) {
    final notamId =    AutorouterNotamId(serie: autorouterNotam.series??'None', 
    number: autorouterNotam.number ?? -1, 
    year: autorouterNotam.year ?? -1); 
    
   
    return AutorouterNotamIdBC(
      autorouterNotam: autorouterNotam,
      notamId: notamId,
    );
  }

  /* 
AutorouterNotamId? getAutorouterNotamIdFromAutorouterNotamGem({
  required String series,
  required int number,
  required int year,
}) {
  try {
    final int numberInt = int.parse(number);
    // year coded with the last 2 digits
    final int yearInt = int.parse(year);
    ;
    return AutorouterNotamId(serie: series, number: numberInt, year: yearInt);
  } catch (e) {
    final err =
        ' unable to create AutorouterNotamId from $number and $year, they can not be parsed as numbers ';
    log('$err, $e');
    return null;
  }
}
 */
class AutorouterNotamId {
  final String serie;
  final int number;
  // year coded with the last 2 digits
  final int year;
  const AutorouterNotamId({
    required this.serie,
    required this.number,
    required this.year,
  });

  @override
  String toString() => '$serie$number/$year)';
}

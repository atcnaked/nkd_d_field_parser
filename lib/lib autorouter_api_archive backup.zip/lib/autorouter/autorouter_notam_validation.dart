import 'autorouter_basetype_notam.dart';

/// get a valid AutorouterBaseTypeNotam
(AutorouterBaseTypeNotam?, String?) getValidFromAutorouterBaseTypeNotam(
  Map<String, dynamic> json,
) {
  // not nullable values can be one of 3 types:

  final Set<String> listDynamicStringKeys = {'itema'};

  final Set<String> boolKeys = {'suppressed'};
  final Set<String> intKeys = {
    'id',
    'modified',

    'number',
    'year',
    'lower',
    'upper',
    'lon',
    'lat',
    'radius',
    'nelon',
    'nelat',
    'swlon',
    'swlat',
    'startvalidity',
    'endvalidity',
  };
  final Set<String> stringKeys = {
    'nof',
    'series',
    'type',
    'fir',
    'code23',
    'code45',
    'traffic',
    'purpose',
    'scope',

    'iteme',
  };

  final Set<String> valueNotNullableKeys = {
    ...stringKeys,
    ...intKeys,
    ...boolKeys,
    ...listDynamicStringKeys,
  };

  // All the key are mandatory: the ones that give null values and those who don't
  // CAUTION to naming: nullableStringKeys means Keys that have values that can be nullable String:
  // (keys can not be null as there are all mandatory)

  final nullableStringKeys = {
    'referredseries',
    'itemd',
    'itemf',
    'itemg',
    'estimation',
  };

  final nullableIntKeys = {'referrednumber', 'referredyear'};
  final mandatoryKeys = {
    ...valueNotNullableKeys,
    ...nullableStringKeys,
    ...nullableIntKeys,
  };

  try {
    final Set<String> jsonKeys = json.keys.toSet();
    final Set<String> missingMandatoryKeys = {};

    // checking that only expected keys are present
    // for the time being all keys are mandatory
    for (var key in mandatoryKeys) {
      if (jsonKeys.contains(key)) {
        jsonKeys.remove(key);
      } else {
        missingMandatoryKeys.add(key);
      }
    }
    String err = '';
    // at the end, jsonKeys and missingMandatoryKeys must be empty
    if (jsonKeys.isNotEmpty) {
      err = '\nunexpected key in json: $jsonKeys';
    }

    if (missingMandatoryKeys.isNotEmpty) {
      err = '$err\nmissing mandatory keys in json: $missingMandatoryKeys';
    }

    if (jsonKeys.isNotEmpty || missingMandatoryKeys.isNotEmpty) {
      err = 'error while parsing json\n$err\nparsed json: \n$json';

      return (null, err);
    }
    for (var key in nullableStringKeys) {
      final value = json[key];
      // print('nullableStringKeys=> key: $key, v.runtimeType: ${v.runtimeType}');
      if (value != null) {
        // if a String? is not null then check that it will be a String
        stringKeys.add(key);
      }
    }
    //
    for (var key in nullableIntKeys) {
      final value = json[key];
      // print('nullableIntKeys=> key: $key, v.runtimeType: ${v.runtimeType}');
      if (value != null) {
        // if a String? is not null then check that it will be a String
        intKeys.add(key);
      }
    }

    List<String> err2 = [];

    for (var pair in [
      (stringKeys, ''.runtimeType),
      (intKeys, 0.runtimeType),
      (boolKeys, false.runtimeType),

      /// here List Dynamic and not List String, may cause bugs if itema is not List String
      (listDynamicStringKeys, [].runtimeType),
    ]) {
      final expectedRuntimeType = pair.$2;
      for (var key in pair.$1) {
       /*  if (key=='') {
          print('json[neLon]: ${json['neLon']}, runtype: ${json['neLon'].runtimeType}');

        } */
        final value = json[key];
        if (value == null) {
          err2.add(
            '$err2\nvalue associated to key $key is null value but is expected to be a $expectedRuntimeType',
          );

          continue;
        }
        final valueruntimeType = value.runtimeType;
        if (valueruntimeType != expectedRuntimeType) {
          err2.add(
            '$err2\ntype of value associated to key $key is $valueruntimeType value but is expected to be a $expectedRuntimeType',
          );
        }

        /////////////
        /////////////
        /////////////
        // all types are as expected but now we must check that itemas is a List of String
        if (expectedRuntimeType == [].runtimeType) {
        //  print('parsing itamaaa');
          //    print('expectedRuntimeType: $expectedRuntimeType');
          //   print('valueruntimeType: $valueruntimeType');
          final itemasList = json[key];

          for (var itemasElement in itemasList) {
            /*   print(
              'element,element.runtimeType = : $itemasElement, ${itemasElement.runtimeType}',
            ); */
            final itemasElementRuntimeType = itemasElement.runtimeType;
            if (itemasElementRuntimeType != ''.runtimeType) {
              err2.add(
                '$err2\ntype of value associated to key $key is expected to be a List<String>\nbut it contains the element $itemasElement of type $itemasElementRuntimeType',
              );
              break;
            } 
            
          /*   else {
            //  print('OK, ');
            } */
          }
        }
      }
    //  print('');
    }
    //print('err2check1: $err2');
    if (err2.isNotEmpty) {
      err2.add('error while parsing json\nerr2\nparsed json: \n$json');

      return (null, err2.join('\n'));
    }


         // neLon: map['neLon'] as int,
/// print('json[nelon]: ${json['nelon']}, runtype: ${json['nelon'].runtimeType}');
    final res = AutorouterBaseTypeNotam.fromMap(json);

    return (res, null);
  } catch (e) {
    final err3 = 'error while parsing, \n$e \nparsed json: $json\n';
    return (null, err3);
  }
}

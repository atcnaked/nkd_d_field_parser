import 'dart:developer';
import 'dart:io';


Future<(String, String)?> getAutorouterIds(String path) async {
  final map = getMapFromResult(await getResultOfRead(path));
  if (map == null) {
    return null;
  }
  try {
    return (map['email']!, map['password']!);
  } catch (e) {
    log('unexpected error in getAutorouterIds: $e');

    return null;
  }
}

/// returns the right of '=' sign (wich is the key) else null if error
Map<String, String>? getMapFromResult((String?, String?) res) {
  final String text;
  if (res.$1 != null) {
    text = res.$1!;
    if (res.$2 != null) {
      log('info: ${res.$2} in getApiKeyFromResult');
    }
  } else {
    log('${res.$2} in getApiKeyFromResult');
    return null;
  }
  final lines = text.split('\n');
  Map<String, String> map = {};
  for (var lineElement in lines) {
    // 1. Strip whitespace and Windows \r characters
   final line = lineElement.trim();

    // 2. Ignore empty lines or comment lines starting with #
    if (line.isEmpty || line.startsWith('#')) {
      continue; 
    }
    // 3. Find the first '=' sign to safely handle passwords that contain '='
    final separatorIndex = line.indexOf('=');
if (separatorIndex == -1) {
      log('No "=" found in line: $line');
      return null;
    }

    final key = line.substring(0, separatorIndex).trim();
    final value = line.substring(separatorIndex + 1).trim();
    
    map[key] = value;
  }
  return map;
}

/// returns either string content/ info  or null/ error
Future<(String?, String?)> getResultOfRead(String path) async {
  final String content;
  String err = '';
  final File file;
  try {
    file = File(path);
    final bool exists = await file.exists();
    if (!exists) {
      err = 'file not exists';
      return (null, err);
    }
  } catch (e) {
    err = 'problem with file: $e';
    return (null, err);
  }

  err = 'file exists';
  try {
    content = await file.readAsString();
  } catch (e) {
    err = '$err, can not read string: $e';
    return (null, err);
  }

  return (content, null);
}

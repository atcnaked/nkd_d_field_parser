// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:async';
import 'dart:convert' show jsonEncode, jsonDecode;
import 'dart:developer';
import 'dart:io';

import 'package:autorouter_api_and_d_parse/autorouter/token/get_autorouter_token.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../other_files.dart/path_handling.dart';
import 'token_response.dart';

final tokenResponseNotifierProvider =
    NotifierProvider<TokenResponseNotifier, TokenResponse?>(
      TokenResponseNotifier.new,
    );

class TokenResponseNotifier extends Notifier<TokenResponse?> {
  Timer? timer;

  @override
  build() {
    ref.onDispose(() {
      // Prevent memory leaks if the provider is destroyed

      timer?.cancel();
    });
    return null;
  }

  void update(TokenResponse? value) {
    timer?.cancel();

    state = value;
if (value == null) {
  return;
}

    if (value.isValid) {
       // Calculate remaining time, not the total lifespan!
      final remainingTime = value.expirationDate.difference(DateTime.now());
      

      timer = Timer(remainingTime, () {
        timer = null;
        state = null;
      });
    }else{
      log('value is not valid.');
    }
  }

  void checkValidity() {
    if (state != null) {
      if (!state!.isValid) {
        state = null;
      }
      ;
    }
  }
}

class TokenPersistenceController {
  // final String path = 'tokenStorage.txt';
  String? path;
  // final String path = await cacheFilePath('tokenStorage','txt' );
  final String tokenStorageName;
  final String tokenStorageExtension;

  Ref ref;
  TokenPersistenceController({
    required this.ref,
    required this.tokenStorageName,
    required this.tokenStorageExtension,
  });

  Future<(TokenResponse?, String?)> retrieveOrReNewAndSaveToken({
    required bool tryToRetrieveFromPersistence,
  }) async {
    try {
      // test file
      // compute storagePath

      final String storagePath = await cacheFilePath(
        tokenStorageName,
        tokenStorageExtension,
      );
      final File file = File(storagePath);

      // if File( storagePath)
      if (tryToRetrieveFromPersistence && await file.exists()) {
        // if file => get from file

        String errorStep = 'readAsString on the file $storagePath';
        try {
          final String fileContent = await file.readAsString();
          errorStep =
              'getting json fwith jsonDecode from fileContent: $fileContent';

          // 3. Decode the string back into a Dart Map<String, dynamic>
          final Map<String, dynamic> jsonMap = jsonDecode(fileContent);

          final TokenResponse savedToken = TokenResponse.fromJson(jsonMap);
          // Crucial addition: Check if the file token is actually still valid!

          if (savedToken.isValid) {
            return (savedToken, null);
          } else {
            log('Info: Token on disk is expired. Moving to server fetch.');
          }
        } catch (e) {
          log(
            'could not load token from file at path: $path, error:$e, errorStep: $errorStep',
          );
        }
      }
      // -- if error (or expired, or file didn't exist) => get From Server --

      final (TokenResponse?, String?) res =
          await getAutorouterTokenFromServer();

      if (res.$1 != null) {
        // -- if success save to file at storagePath --
        final saveResult = await saveToken(res.$1!, storagePathP: storagePath);

        if (saveResult != null) {
          log('saveToken error: $saveResult');
        }

        return (res.$1, saveResult);
      }

      // If the server fetch failed (e.g., wrong password, no internet)
      return (null, 'error while getting AutorouterToken from server');
    } catch (e) {
      return (null, 'Critical Error in token management: $e');
    }
  }

/// Try to save the TokenResponse and returns the error (null if successfull).
  Future<String?> saveToken(
    TokenResponse tokenResponse, {
    Duration? timeout,
    required String? storagePathP,
  }) async {
    final String storagePath =
        storagePathP ??
        await cacheFilePath(tokenStorageName, tokenStorageExtension);

    final File file = File(storagePath);
    try {
      //  await file.writeAsString(tokenResponse.toJson());
      // jsonEncode converts the Map into the actual JSON string
      await file
          .writeAsString(jsonEncode(tokenResponse.toJson()))
          .timeout(
            timeout ?? Duration(seconds: 10),
            onTimeout: () {
              log('timeout, token could not be saved...');
              throw Exception('timeout, token could not be saved...');
            },
          );
      ;
      return null;
    } catch (e) {
      return 'unable to save token, error $e';
    }
  }
}

Future<(TokenResponse?, String?)> getAutorouterTokenFromServer() async {
  final myEmail = "fdfffsdfsfsqsfds@gmail.com";
  final myPassword = "zzzzzzzzz!";
  return await getAutorouterToken(email: myEmail, password: myPassword);
}

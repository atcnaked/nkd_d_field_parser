// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:async';
import 'dart:convert' show jsonDecode;
import 'dart:developer';

import 'package:autorouter_api_and_d_parse/autorouter/token/get_autorouter_token.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'secure_storage_service.dart';
import 'token_response.dart';

final tokenResponseNotifierProvider =
    NotifierProvider<TokenResponseNotifier, TokenResponse?>(
      TokenResponseNotifier.new,
    );

class TokenResponseNotifier extends Notifier<TokenResponse?> {
  Timer? timer;

  @override
  build() {
    ref.onDispose(() {
      // Prevent memory leaks if the provider is destroyed

      timer?.cancel();
    });
    return null;
  }

  void update(TokenResponse? value) {
    timer?.cancel();

    state = value;
    if (value == null) {
      return;
    }

    if (value.isValid) {
      // Calculate remaining time, not the total lifespan!
      final remainingTime = value.expirationDate.difference(DateTime.now());

      timer = Timer(remainingTime, () {
        timer = null;
        state = null;
      });
    } else {
      log('value is not valid');
    }
  }

  void checkValidity() {
    if (state != null) {
      if (!state!.isValid) {
        state = null;
      }
      ;
    }
  }

  /// Forces a fresh network request using the credentials currently in Secure Storage
  Future<void> forceRefreshFromServer() async {
    // 1. You could set state to a loading state here if you are using AsyncValue

    // 2. Fetch the token (this method already pulls credentials securely from your controller!)
    final controller = TokenPersistenceController(ref: ref);
    final (token, error, needsLogin) = await controller
        .retrieveOrReNewAndSaveToken(
          tryToRetrieveFromPersistence:
              false, // Bypass the saved token to force a real login
        );

    if (token != null) {
      // 3. Success! The Notifier's update() method handles the timers and state mapping
      update(token);
    } else {
      // Throw an error so the UI catch block can display the error message
      throw Exception(error ?? 'Login failed');
    }
  }
}

final tokenPersistenceControllerProvider = Provider(
  (ref) => TokenPersistenceController(ref: ref),
);

class TokenPersistenceController {
  final SecureStorageService _secureStorage = SecureStorageService();

  Ref ref;
  TokenPersistenceController({required this.ref});

  /// get a TokenResponse + infos else null + error, and true if must enter credentials
  Future<(TokenResponse?, String?, bool?)> retrieveOrReNewAndSaveToken({
    required bool tryToRetrieveFromPersistence,
  }) async {
    try {
      if (tryToRetrieveFromPersistence) {
        String errorStep = 'Attempt to read from Secure Storage';
        try {
          final String? fileContent = await _secureStorage.getToken();
          if (fileContent != null) {
            errorStep =
                'getting json with jsonDecode on fileContent: $fileContent';

            // Decode the string back into a Dart Map<String, dynamic>
            final Map<String, dynamic> jsonMap = jsonDecode(fileContent);
            errorStep = 'building TokenResponse.fromJson(jsonMap: $jsonMap)';
            final TokenResponse savedToken = TokenResponse.fromJson(jsonMap);
            // Crucial addition: Check if the file token is actually still valid!
            print('savedToken: $savedToken');
            if (savedToken.isValid) {
              log('Loaded valid token from Secure Storage.');

              return (savedToken, null, null);
            } else {
              log('Info: Token on disk is expired.. Moving to server fetch.');
            }
          } else {
            log('fileContent = null, no token in secure storage');
          }
        } catch (e) {
          log(
            'could not load token from Secure Storage, error:$e, errorStep: $errorStep',
          );
        }
      }
      // -- if error (or expired, or file didn't exist) => get From Server --
      log('Fetching fresh token from server...');

      final (TokenResponse?, String?, bool?) res =
          await getAutorouterTokenFromServer();

      if (res.$1 != null) {
        log('got fresh token from server.');

        // Save the new token back to Secure Storage
        final saveResult = await saveTheToken(res.$1!);
        if (saveResult != null) {
          log('saveToken error: $saveResult');
        }
        return (res.$1, saveResult, null);
      }

      // If the server fetch failed (e.g., wrong password, no internet)
      // if no stored credentials then must enter them
      if (res.$3 == true) {
        log('at least  one of the credentials is null');
        return (null, null, true);
      }
      // else other errors
      return (
        null,
        res.$2 ?? 'Unknown error fetching AutorouterToken from server',
        null,
      );
    } catch (e) {
      return (null, 'Critical Error in token management: $e', null);
    }
  }

  Future<void> clearCredetialsAndToken() async {
    try {
      await _secureStorage.clearAll();
      log('credetials and token successfully cleared !');
    } catch (e) {
      log(
        'unable to clear credetials and token from Secure Storage, error: $e',
      );
    }
  }

  /// Try to save the TokenResponse, returns the error if unable (null if successfull).
  Future<String?> saveTheToken(
    TokenResponse tokenResponse, {
    Duration? timeout,
  }) async {
    try {
      // jsonEncode converts the Map into the actual JSON string
      // checks

      await _secureStorage
          .saveToken(tokenResponse.toJson())
          .timeout(
            timeout ?? Duration(seconds: 10),
            onTimeout: () {
              log('timeout, token could not be saved...');
              // Throw an exception so the catch block properly handles it
              throw TimeoutException('timeout, token could not be saved...');
            },
          );

      /// here we check that TokenResponse encode decode works

      String step = '1';
      final json = tokenResponse.toJson();
      step = '2';

      final String fileContent = json;
      // Decode the string back into a Dart Map<String, dynamic>
      final Map<String, dynamic> jsonMap = jsonDecode(fileContent);
      step = '3';
      final TokenResponse savedTokenResponse = TokenResponse.fromJson(jsonMap);
      step = '4';
      if (tokenResponse == savedTokenResponse) {
        log('TokenResponse encode decode OK');
      } else {
        print('tokenResponse != savedTokenResponse !! ');
        print('tokenResponse: $tokenResponse');
        print('savedTokenResponse: $savedTokenResponse');

        throw Exception('TokenResponse encode decode error, step: $step');
      }
      return null;
    } catch (e) {
      return 'unable to save token to Secure Storage, error $e';
    }
  }

  /// returns TokenResponse + infos else null + error, and true if must enter credentials
  ///
  /// Securely fetches the token without hardcoding passwords
  Future<(TokenResponse?, String?, bool?)>
  getAutorouterTokenFromServer() async {
    final String emailStr;
    final String passwordStr;

    try {
      final creds = await _secureStorage.getCredentials();

      final email = creds.$1;
      final password = creds.$2;

      if (email == null || password == null) {
        return (
          null,
          'No credentials found in Secure Storage. User must log in.',
          true,
        );
      }
      emailStr = email;
      passwordStr = password;
    } catch (e) {
      return (null, 'error while getting Credentials: $e', null);
    }
    try {
      final tokenR = await getAutorouterToken(
        email: emailStr,
        password: passwordStr,
      );

      if (tokenR.$1 != null) {
        return (tokenR.$1, tokenR.$2, null);
      }

      return (null, 'Server rejected authentication, ${tokenR.$2}', null);
    } catch (e) {
      return (null, 'Network error during auth: $e', false);
    }
  }
}

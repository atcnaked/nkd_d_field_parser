










import 'dart:convert';
import 'package:http/http.dart' as http;


void checkApiVersion() async {
  final (version, error) = await getAutorouterSystemVersion();

  if (version != null) {
    print('Connected to Autorouter API Version: ${version.displayVersion}');
    print('Is Production Server: ${version.production}');
    print('Are we authenticated yet? ${version.auth}');
  } else {
    print('Failed to reach Autorouter: $error');
  }
}

/// Fetches the current API version from Autorouter.
/// Returns a record containing the AutorouterVersion object, or an error string.
Future<(AutorouterVersion?, String?)> getAutorouterSystemVersion() async {
  final url = Uri.parse('https://api.autorouter.aero/v1.0/system/version');

  try {
    final response = await http.get(
      url,
      headers: {
        'Accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> jsonMap = jsonDecode(response.body);
      final versionData = AutorouterVersion.fromJson(jsonMap);
      
      return (versionData, null);
    } else {
      return (null, 'Server returned status code: ${response.statusCode}');
    }
  } catch (e) {
    return (null, 'Network error fetching version: $e');
  }
}

















class AutorouterVersion {
  final int major;
  final int minor;
  final int patch;
  final bool production;
  final bool auth;
  final int minVersionMajor;
  final int minVersionMinor;

  AutorouterVersion({
    required this.major,
    required this.minor,
    required this.patch,
    required this.production,
    required this.auth,
    required this.minVersionMajor,
    required this.minVersionMinor,
  });

  factory AutorouterVersion.fromJson(Map<String, dynamic> json) {
    // Safely parse the nested minVersion object
    final minVersionMap = json['minVersion'] as Map<String, dynamic>? ?? {};

    return AutorouterVersion(
      major: json['major'] ?? 0,
      minor: json['minor'] ?? 0,
      patch: json['patch'] ?? 0,
      production: json['production'] ?? false,
      auth: json['auth'] ?? false,
      minVersionMajor: minVersionMap['major'] ?? 0,
      minVersionMinor: minVersionMap['minor'] ?? 0,
    );
  }

  /// Helper getter to format the version nicely for your UI (e.g., "1.0.19")
  String get displayVersion => '$major.$minor.$patch';
}
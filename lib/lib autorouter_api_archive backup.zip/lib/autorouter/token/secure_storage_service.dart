import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  // Create a singleton instance of the secure storage
  final _storage = const FlutterSecureStorage();

  // Define your secure keys
  static const _keyEmail = 'autorouter_email';
  static const _keyPassword = 'autorouter_password';
  static const _keyToken = 'autorouter_token_json';

  // ==========================================
  // CREDENTIALS MANAGEMENT
  // ==========================================
  
  Future<void> saveCredentials({required String email, required String password}) async {
    await _storage.write(key: _keyEmail, value: email);
    await _storage.write(key: _keyPassword, value: password);
  }

  /// Returns a Record: (email, password)
  Future<(String?, String?)> getCredentials() async {
    final email = await _storage.read(key: _keyEmail);
    final password = await _storage.read(key: _keyPassword);
    return (email, password);
  }

  // ==========================================
  // TOKEN MANAGEMENT
  // ==========================================

  Future<void> saveToken(String tokenJsonString) async {
    await _storage.write(key: _keyToken, value: tokenJsonString);
  }

  Future<String?> getToken() async {
    return await _storage.read(key: _keyToken);
  }

  // Handy for "Logout" functionality
  Future<void> clearAll() async {
    await _storage.deleteAll();
    
  }
}
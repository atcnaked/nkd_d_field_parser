import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../get_pib_all_page.dart';
import '../get_pib_fetch_once.dart';
import 'check_api_version.dart';
import 'get_autorouter_ids.dart';
import 'secure_storage_service.dart';
import 'token_provider_secure_storage.dart';
import 'token_response.dart';

class AutoLoadAutorouterIdsButtonZZ extends ConsumerWidget {
  const AutoLoadAutorouterIdsButtonZZ({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () async {
            final ids = await getAutorouterIds('.env');
            if (ids == null) {
              log('unable to load autorouter ids from file');
              return;
            }

            log('loaded autorouter ids: $ids');
            final secureStorage = SecureStorageService();
            await secureStorage.saveCredentials(
              email: ids.$1,
              password: ids.$2,
            );
            log('autorouter ids should have been save in Secure Storage');
          },
          child: Text('Load Autorouter ids \nfrom .env file'),
        ),
      ],
    );
  }
}

class GetPIBAllPageButton extends ConsumerWidget {
  const GetPIBAllPageButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TokenResponse? tkr = ref.watch(tokenResponseNotifierProvider);
    return Column(
      children: [
        ElevatedButton(
          onPressed: () async {
            final (version, error) = await getAutorouterSystemVersion();

            if (version != null) {
              print(
                'Connected to Autorouter API Version: ${version.displayVersion}',
              );
              print('Is Production Server: ${version.production}');
              print('Are we authenticated yet? ${version.auth}');
            } else {
              print('Failed to reach Autorouter: $error');
            }

            /*   if (tkr != null) {
              log('initializeAppAndGetPibAllPage');
              getPibAllPage(tkr.accessToken);
            } */
          },
          child: Text('get Autorouter System Version'),
        ),/* 
        ElevatedButton(
          onPressed: () {
            if (tkr != null) {
              log('initializeAppAndGetPibAllPage');
              getPibAllPage(tkr.accessToken);
            }
          },
          child: Text('fetch multi page'),
        ), */

        ElevatedButton(
          onPressed: () async {
            if (tkr != null) {
              log('fetchOnce');

              final List<String> icaosCode3Fir = ['LFBB', 'LFFF', 'LFMM'];
              final List<String> icaosCodeBB = ['LFBB'];
              final List<String> icaosCode = icaosCode3Fir;
              final int? limit = null;
              final int tries = 2;
              final DateTime? startValidity = null;
              final DateTime? endValidity = DateTime.now().copyWith(day: DateTime.now().day + 1);

              final timeoutDuration = Duration(seconds: 10);

              final GetNotamParameters getNotamParameters = GetNotamParameters(
                authority: 'api.autorouter.aero',
                unencodedPath: '/v1.0/notam',
                // headers: headers,
                token: tkr.accessToken,
                timeout: timeoutDuration,
                icaoCodes: icaosCode,
                limit: limit ?? 100,
                startValidity: startValidity,
                endValidity: endValidity,
              );
  
             await fetchNotamsRetry(getNotamParameters,tries: tries);
            }
          },
          child: Text('fetch page with retry'),
        ),
        ElevatedButton(
          onPressed: () async {
            if (tkr != null) {
              log('fetchOnce');

              final List<String> icaosCode3Fir = ['LFBB', 'LFFF', 'LFMM'];
              final List<String> icaosCodeBB = ['LFBB'];
              final List<String> icaosCode = icaosCode3Fir;
              final int? limit = null;
              final int? retryNb = null;
              final DateTime? startValidity = null;
              final DateTime? endValidity = DateTime.now().copyWith(day: DateTime.now().day + 1);

              final timeoutDuration = Duration(seconds: 10);

              final GetNotamParameters getNotamParameters = GetNotamParameters(
                authority: 'api.autorouter.aero',
                unencodedPath: '/v1.0/notam',
                // headers: headers,
                token: tkr.accessToken,
                timeout: timeoutDuration,
                icaoCodes: icaosCode,
                limit: limit ?? 100,
                startValidity: startValidity,
                endValidity: endValidity,
              );

              await fetchNotamsOnce(getNotamParameters);
            }
          },
          child: Text('fetch page once'),
        ),
      ],
    );
  }
}

class TokenButton extends ConsumerWidget {
  const TokenButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TokenResponse? tkr = ref.watch(tokenResponseNotifierProvider);
    return Column(
      children: [
        tkr == null ? Text('No Token') : Text('Token Exists'),
        /* 
        ElevatedButton(
          onPressed: () async {
            log('get TokenZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ starts ');
            final res = await ref
                .read(tokenPersistenceControllerProvider)
                .retrieveOrReNewAndSaveToken(
                  tryToRetrieveFromPersistence: true,
                );
            if (res.$3 == true) {
              log('res.3 == true');
              return;
            }
            if (res.$1 != null && res.$1!.isValid) {
              log('res.1 != null && res.1!.isValid');
              ref.read(tokenResponseNotifierProvider.notifier).update(res.$1);
            }
            log('get TokenZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ done ');
          },
          child: Text('getTokenZZZZZZZZZZZZZZZZZZZZZZZ'),
        ), */
      ],
    );
  }
}

class TokenCredentialsWidget extends ConsumerStatefulWidget {
  const TokenCredentialsWidget({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _TokenCredentialsWidgetState();
}

class _TokenCredentialsWidgetState
    extends ConsumerState<TokenCredentialsWidget> {
  bool showCredentialsWidget = false;
  @override
  Widget build(BuildContext context) {
    final TokenResponse? tkr = ref.watch(tokenResponseNotifierProvider);

    return Column(
      children: [
        tkr == null ? Text('No Token') : Text('Token Exists'),

        ElevatedButton(
          onPressed: () async {
            final res = await ref
                .read(tokenPersistenceControllerProvider)
                .retrieveOrReNewAndSaveToken(
                  tryToRetrieveFromPersistence: true,
                );

            if (res.$3 == true) {
              log('res.3 == true');
              setState(() {
                showCredentialsWidget = true;
              });
              return;
            }

            if (res.$1 != null && res.$1!.isValid) {
              log('res.1 != null && res.1!.isValid');
              ref.read(tokenResponseNotifierProvider.notifier).update(res.$1);
            }
            log('get Token done ');
          },
          child: Text('get Token'),
        ),
        if (showCredentialsWidget) AutorouterLoginWidget(),
        if (showCredentialsWidget)
          ElevatedButton(
            onPressed: () {
              setState(() {
                showCredentialsWidget = false;
              });
            },
            child: Text('X close'),
          ),
        if (!showCredentialsWidget)
          ElevatedButton(
            onPressed: () {
              setState(() {
                showCredentialsWidget = true;
              });
            },
            child: Text('show creds'),
          ),
        if (showCredentialsWidget)
          ElevatedButton(
            onPressed: () {
              ref
                  .read(tokenPersistenceControllerProvider)
                  .clearCredetialsAndToken();
              /*  setState(() {
                showCredentialsWidget = false;
              }); */
            },
            child: Text('clear credentials and token'),
          ),
      ],
    );
  }
}

class AutorouterLoginWidget extends ConsumerStatefulWidget {
  const AutorouterLoginWidget({super.key});

  @override
  ConsumerState<AutorouterLoginWidget> createState() =>
      _AutorouterLoginWidgetState();
}

class _AutorouterLoginWidgetState extends ConsumerState<AutorouterLoginWidget> {
  // 1. Controllers for the text fields
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // 2. Local state for UI feedback
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    // ALWAYS dispose controllers to prevent memory leaks!
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    // Basic validation
    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter both your email and password.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null; // Clear previous errors
    });

    try {
      // 1. Save the raw credentials to Windows Secure Storage (DPAPI)
      final secureStorage = SecureStorageService();
      await secureStorage.saveCredentials(email: email, password: password);

      // 2. Tell your Riverpod Notifier to wake up and fetch the token using the newly saved credentials!
      // (Assuming you added a forceRefreshFromServer() method to your AsyncNotifier)
      await ref
          .read(tokenResponseNotifierProvider.notifier)
          .forceRefreshFromServer();

      // Note: If you are using GoRouter with a redirect based on the tokenProvider's state,
      // you don't even need to write navigation code here. The app will route automatically!
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Login failed. Please check your credentials.';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Autorouter Login',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),

          // --- Error Message Display ---
          if (_errorMessage != null) ...[
            Container(
              padding: const EdgeInsets.all(8),
              color: Colors.red.shade100,
              child: Text(
                _errorMessage!,
                style: TextStyle(color: Colors.red.shade900),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 16),
          ],

          // --- Email Field ---
          TextField(
            controller: _emailController,
            decoration: const InputDecoration(
              labelText: 'Email Address',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.email),
            ),
            keyboardType: TextInputType.emailAddress,
            textInputAction:
                TextInputAction.next, // Moves to password field on "Enter"
          ),
          const SizedBox(height: 16),

          // --- Password Field ---
          TextField(
            controller: _passwordController,
            decoration: const InputDecoration(
              labelText: 'Password',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.lock),
            ),
            obscureText: true, // Hides the password dots
            textInputAction: TextInputAction.done,
            onSubmitted: (_) =>
                _submit(), // Triggers submit if user hits "Enter" on the keyboard
          ),
          const SizedBox(height: 24),

          // --- Submit Button ---
          SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _submit,
              child: _isLoading
                  ? const SizedBox(
                      height: 24,
                      width: 24,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text(
                      'Save Credentials & Login',
                      style: TextStyle(fontSize: 16),
                    ),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              final ids = await getAutorouterIds('.env');
              if (ids == null) {
                log('unable to load autorouter ids from file');
                return;
              }

              log('loaded autorouter ids: $ids');
              /* 
            final secureStorage = SecureStorageService();
            await secureStorage.saveCredentials(
              email: ids.$1,
              password: ids.$2,
            );
            log('autorouter ids should have been save in Secure Storage');
             */

              _emailController.text = ids.$1;
              _passwordController.text = ids.$2;
            },
            child: Text('Load Autorouter ids \nfrom .env file'),
          ),
        ],
      ),
    );
  }
}

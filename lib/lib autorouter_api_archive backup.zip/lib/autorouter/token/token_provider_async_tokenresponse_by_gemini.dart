import 'dart:async';
import 'dart:developer';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'token_response.dart';
// import 'token_persistence_controller.dart'; // Assuming this is where your controller lives

final tokenResponseNotifierProvider =
    AsyncNotifierProvider<TokenResponseNotifier, TokenResponse?>(
  TokenResponseNotifier.new,
);

class TokenResponseNotifier extends AsyncNotifier<TokenResponse?> {
  Timer? _timer;

  @override
  Future<TokenResponse?> build() async {
    // 1. Clean up resources when the provider is destroyed
    ref.onDispose(() {
      _timer?.cancel();
    });

    // 2. Perform your async initialization right here!
    // Assuming you expose your controller via a Provider:
    final controller = ref.read(tokenPersistenceControllerProvider);
    
    final (token, error) = await controller.retrieveOrReNewAndSaveToken(
      tryToRetrieveFromPersistence: true,
    );

    if (error != null) {
      log('Initialization Warning: $error');
    }

    // 3. Set up the expiration timer if we successfully got a token
    if (token != null) {
      _setupTimer(token);
    }

    // 4. Return the initial state
    return token;
  }

  void _setupTimer(TokenResponse token) {
    _timer?.cancel();

    if (token.isValid) {
      final remainingTime = token.expirationDate.difference(DateTime.now());
      
      _timer = Timer(remainingTime, () {
        log('Token expired via internal timer.');
        _timer = null;
        
        // Update the AsyncValue state safely
        state = const AsyncData(null);
        
        // Alternatively, you could call a refresh method here to auto-renew it in the background!
      });
    } else {
      log('Provided token is already invalid.');
    }
  }

  /// Manually force a fresh login/fetch from the server
  Future<void> forceRefreshFromServer() async {
    // Set the state to loading so the UI can react
    state = const AsyncLoading();
    
    // AsyncValue.guard safely catches errors and maps them to AsyncError
    state = await AsyncValue.guard(() async {
      final controller = ref.read(tokenPersistenceControllerProvider);
      
      final (token, _) = await controller.retrieveOrReNewAndSaveToken(
        tryToRetrieveFromPersistence: false, // Bypass secure storage
      );
      
      if (token != null) {
        _setupTimer(token);
      }
      
      return token;
    });
  }

  /// Clear the token (e.g., when the user logs out)
  Future<void> logout() async {
    _timer?.cancel();
    
    // TODO: You should also call your SecureStorageService here to clear the saved credentials/token!
    // await ref.read(secureStorageProvider).clearAll();
    
    state = const AsyncData(null);
  }
}
import 'dart:convert';
import 'dart:developer';
import 'package:autorouter_api_and_d_parse/autorouter/token/token_response.dart'
    show TokenResponse;
import 'package:http/http.dart' as http;

Future<(TokenResponse?, String?)> getAutorouterToken({
  required String email,
  required String password,
}) async {
  // 1. Define the endpoint URL
  final url = Uri.parse('https://api.autorouter.aero/v1.0/oauth2/token');

  try {
    // 2. Make the POST request
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'grant_type': 'client_credentials',
        'client_id': email,
        'client_secret': password,
      },
    );

    // 3. Handle the response
    if (response.statusCode == 200) {
      // Decode the JSON response
      final Map<String, dynamic> data = jsonDecode(response.body);
      // {"access_token":"c9823043ea2b4f004a01c63004585e4d7d99d7b0","expires_in":604800,"token_type":"Bearer","scope":null}
      log('data: $data');
      // data: {access_token: 02450cc24d54b70f90c8411e25eef6b1261a903c, expires_in: 604800, token_type: Bearer, scope: null}
      log('response.body: ${response.body}');

      // response.body: {"access_token":"02450cc24d54b70f90c8411e25eef6b1261a903c","expires_in":604800,"token_type":"Bearer","scope":null}
      try {
        data['access_token'] as String;
        data['expires_in'] as int;
      } catch (e) {
        return (
          null,
          'error while extracting keys "access_token" or "expires_in" from $data; error: $e',
        );
      }

      return (TokenResponse.fromJson(data), null);
      /* 

      print('Token successfully retrieved!');
      final String tokenType = data['token_type'];
      final String scope = data['scope'];

      return (TokenResponse(accessToken, expiresIn, tokenType, scope), null); */
      /* 
class TokenResponse {
  final String accessToken;
  final int expiresIn;
  final String tokenType;
  final String? scope;
 */
    } else {
      // Handle authentication failures (e.g., 401 Unauthorized)
      return (
        null,
        'Failed to authenticate. Status Code: ${response.statusCode}. \nError Response: ${response.body}',
      );
    }
  } catch (e) {
    return (null, 'Network error occurred: $e');
  }
}

// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

/* 
What these fields actually mean for you:

    access_token: ("c9823043ea...") This is the golden key. This exact string is what you inject into your HTTP Authorization header as Bearer c9823043ea... to fetch your NOTAMs.

    expires_in: (604800) This is highly important! This is the time to live in seconds. 604800 seconds equals exactly 7 days.

    token_type: ("Bearer") This just confirms the standard HTTP authentication scheme you are required to use in your headers.

    scope: (null) In OAuth, scopes define specific permissions (e.g., read-only vs. read-write). Because it is null, it means Autorouter is just granting your client default/full access to the APIs your account is authorized for.

The Pro-Tip for your Flutter App

Because this token is valid for 7 entire days (604800 seconds), do not request a new token every time you fetch NOTAMs.

Making an authentication request every time a user pulls to refresh the PIB is bad practice and can get your API access rate-limited. Instead, when you fetch this token, save it locally using a package like flutter_secure_storage or shared_preferences, along with its calculated expirationDate.

Before you make a call to the NOTAM endpoint, just check isValid. If it is true, use the saved token. If it is false, call your token endpoint to get a fresh one!
 */

/// TokenResponse, caution for keys
/// data: {access_token: 4dccf2139826fcac193793b1123a1430d3ba3138, expires_in: 604800, token_type: Bearer, scope: null}
/// response.body: {"access_token":"4dccf2139826fcac193793b1123a1430d3ba3138","expires_in":604800,"token_type":"Bearer","scope":null}
class TokenResponse {
  final String accessToken;
  final int expiresIn;
  final String tokenType;
  final String? scope;

  TokenResponse({
    required this.accessToken,
    required this.expiresIn,
    required this.tokenType,
    this.scope,
  });

// data: {access_token: 4dccf2139826fcac193793b1123a1430d3ba3138, expires_in: 604800, token_type: Bearer, scope: null}
// response.body: {"access_token":"4dccf2139826fcac193793b1123a1430d3ba3138","expires_in":604800,"token_type":"Bearer","scope":null}
  factory TokenResponse.fromJson(Map<String, dynamic> json) {
    return TokenResponse(
      accessToken: json['access_token'] ?? '',
      expiresIn: json['expires_in'] ?? 0,
      tokenType: json['token_type'] ?? 'Bearer',
      scope: json['scope'],
    );
  }
  // Helper getter to determine when the token actually expires
  DateTime get expirationDate {
    return DateTime.now().add(Duration(seconds: expiresIn));
  }

  // Helper to check if the token is still valid
  bool get isValid => DateTime.now().isBefore(expirationDate);

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'access_token': accessToken,
      'expires_in': expiresIn,
      'token_type': tokenType,
      'scope': scope,
    };
  }

  factory TokenResponse.fromMap(Map<String, dynamic> map) {
    return TokenResponse(
      accessToken: map['access_token'] as String,
      expiresIn: map['expires_in'] as int,
      tokenType: map['token_type'] as String,
      scope: map['scope'] != null ? map['scope'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());


  @override
  String toString() {
    return '(accessToken: $accessToken, \nexpiresIn: $expiresIn, \ntokenType: $tokenType, \nscope: $scope)';
  }

  @override
  bool operator ==(covariant TokenResponse other) {
    if (identical(this, other)) return true;
  
    return 
      other.accessToken == accessToken &&
      other.expiresIn == expiresIn &&
      other.tokenType == tokenType &&
      other.scope == scope;
  }

  @override
  int get hashCode {
    return accessToken.hashCode ^
      expiresIn.hashCode ^
      tokenType.hashCode ^
      scope.hashCode;
  }
}

// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';
import 'dart:developer';

import 'package:http/http.dart' as http;
import 'package:http/http.dart';

//import 'autorouter_notam.dart';
import 'autorouter_basetype_notam.dart';
import 'autorouter_notam_validation.dart';

////
Future<((List<AutorouterBaseTypeNotam>, int)?, String?)> fetchNotamsRetry(
  // String accessToken,
  // List<String> icaoCodes,
  GetNotamParameters getNotamParameters, {
  required int tries,

  // String otherPArams,
}) async {
  int tryNb = 1;
  try {
    while (tryNb <= tries) {
      log('attempt $tryNb/$tries to fetch notams');
      final ((List<AutorouterBaseTypeNotam>, int)?, String?) res =
          await fetchNotamsOnce(getNotamParameters);
      if (res.$1 != null) {
        return res;
      }

      tryNb++;
    }

    return (null, 'error, all notams fetch attempts failed');
  } catch (e) {
    return (null, 'error $e in notams fetch attempt $tryNb/$tries');
  }
}

/// Fetches NOTAMs only once (no retry) based on the official Autorouter API specification.
Future<((List<AutorouterBaseTypeNotam>, int)?, String?)> fetchNotamsOnce(
  // String accessToken,
  // List<String> icaoCodes,
  GetNotamParameters getNotamParameters,

  // String otherPArams,
) async {
  //
  int offset = 0;
  int totalItems = -1;
  int partFetchCount = 1;

  Map<int, AutorouterBaseTypeNotam> uniqueNotamsAutorouterBaseTypeNotam = {};

  bool hasMoreData = true;
  while (hasMoreData) {
    log('Fetching NOTAMs from offset $offset...');
    final ((List<AutorouterBaseTypeNotam>, int)?, String?) fetchPart =
        await fetchFromOffset(
          getNotamParameters: getNotamParameters,
          offset: offset,
          getTotal: totalItems == -1 ? true : false,
        );
    final List<AutorouterBaseTypeNotam> fetchedList;

    if (fetchPart.$2 != null) {
      return (null, 'error in fetchOnce, ${fetchPart.$2}');
    } else {
      fetchedList = fetchPart.$1!.$1;
      // update totalItems only if it hasn't already been set to a positive value
      // we could also use offset==0 instead of totalItems<0
      if (totalItems < 0) {
        assert(offset == 0);
        totalItems = fetchPart.$1!.$2;
      }
    }
    for (var notam in fetchedList) {
      // avoids duplicates
      uniqueNotamsAutorouterBaseTypeNotam[notam.id] = notam;
    }
    if (fetchedList.length == 0) {
      hasMoreData = false;
    } else {
      offset += getNotamParameters.limit;
      partFetchCount++;
    }
  }

  log(
    'Finished! Downloaded ${uniqueNotamsAutorouterBaseTypeNotam.length} unique NOTAMs out of $totalItems reported on the server ($partFetchCount http get done)',
  );

  return (
    (uniqueNotamsAutorouterBaseTypeNotam.values.toList(), totalItems),
    null,
  );
}

Future<((List<AutorouterBaseTypeNotam>, int)?, String?)> fetchFromOffset({
  required int offset,
  required GetNotamParameters getNotamParameters,
  required bool getTotal,
}) async {
  final List<AutorouterBaseTypeNotam> listRes = [];
  int totalItems = -1;

  final Response response;
  try {
    final headers = {
      'Authorization': 'Bearer ${getNotamParameters.token}',
      'Accept': 'application/json',
    };

    final queryParams = {
      'itemas': jsonEncode(getNotamParameters.icaoCodes),
      'limit': getNotamParameters.limit.toString(),
      'offset': offset.toString(),
    };

    // 2. Handle the optional Unix epoch time conversions
    if (getNotamParameters.startValidity != null) {
      // Convert Dart DateTime to seconds since Unix epoch
      queryParams['startvalidity'] =
          (getNotamParameters.startValidity!.millisecondsSinceEpoch ~/ 1000)
              .toString();
    }

    if (getNotamParameters.endValidity != null) {
      queryParams['endvalidity'] =
          (getNotamParameters.endValidity!.millisecondsSinceEpoch ~/ 1000)
              .toString();
    }

    final uri = Uri.https(
      getNotamParameters.authority,
      getNotamParameters.unencodedPath,
      queryParams,
    );

    response = await http
        .get(uri, headers: headers)
        .timeout(
          getNotamParameters.timeout,
          onTimeout: () {
            throw GetTimeoutException('timeoutError in http.get', uri: uri);
          },
        );
  } on GetTimeoutException catch (e) {
    return (null, 'error in http.get while fetching notams, $e');
  } catch (e) {
    return (null, 'network error while fetching notams, $e');
  }
  if (response.statusCode == 200) {
    final jsonData = jsonDecode(response.body);

    // initilizing totalItems at the first fetch
    if (getTotal) {
      if (jsonData['total'] == null) {
        return (
          null,
          'unexpected null value for jsonData["total"], error while fetching NOTAMs',
        );
      }

      if (jsonData['total'] < 0) {
        return (
          null,
          'unexpected negative value: ${jsonData['total']} for jsonData["total"] (which must be non negative), error while fetching NOTAMs',
        );
      }
      totalItems = jsonData['total'];
    }
    if (jsonData['rows'] == null) {
      return (
        null,
        'unexpected null value for jsonData["rows"], error while fetching NOTAMs,',
      );
    }

    final List rows = jsonData['rows'];

    log('found ${rows.length} rows ');
    if (rows.length == 0) {
      return ((listRes, totalItems), null);
    }
    // Parse the rows and drop them into the Map
    int counter = 0;
    for (var row in rows) {
      counter++;
      final (AutorouterBaseTypeNotam?, String?) res =
          getValidFromAutorouterBaseTypeNotam(row);
      final AutorouterBaseTypeNotam autorouterBaseTypeNotam;
      if (res.$1 != null) {
        autorouterBaseTypeNotam = res.$1!;
        listRes.add(autorouterBaseTypeNotam);
      } else {
        //  log('validOrError.2: ${res.$2}');
        return (
          null,
          'error when parsing AutorouterBaseTypeNotam (position $counter/${rows.length}) \n${res.$2}',
        );
      }
    }

    return ((listRes, totalItems), null);
  } else {
    // If we hit an error (like a 401 or 500), break the loop so we don't get stuck forever
    return (null, 'Failed to fetch. Status Code: ${response.statusCode}');
  }
}

class GetTimeoutException implements Exception {
  final String message;
  final Uri? uri;

  GetTimeoutException(this.message, {this.uri});

  @override
  String toString() =>
      'GetTimeoutException: $message${uri != null ? ' (URI: $uri)' : ''}';
}

/// the params for the http get. The 'offset' key of queryParams will be overwritten
class GetNotamParameters {
  // final int offset;
  final String token;
  final String authority;
  final String unencodedPath;
  final List<String> icaoCodes;
  final int limit;
  final DateTime? startValidity;
  final DateTime? endValidity;
  //final Map<String, String> queryParams;
  // final Map<String, String> headers;
  final Duration timeout;
  GetNotamParameters({
    // required this.offset,
    required this.authority,
    required this.unencodedPath,
    // required this.headers,
    required this.timeout,
    required this.icaoCodes,
    required this.limit,
    required this.token,
    required this.startValidity,
    required this.endValidity,
  });
}
